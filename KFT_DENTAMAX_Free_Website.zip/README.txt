KFT DENTAMAX — bilingual one-page website
Files:
- index.html: complete responsive website in English + Bangla

Preview:
1. Download the ZIP and extract it.
2. Double-click index.html to preview in your browser.

Free publishing with GitHub Pages:
1. Sign in or create an account at https://github.com
2. Create a new public repository named kftdentamax.github.io (if available).
3. Upload index.html to the repository's root.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for publishing; GitHub will show the public URL if the repository name is available.

Before publishing, confirm the phone, email, address and WhatsApp number. The WhatsApp link is formatted with Bangladesh country code (+880).
